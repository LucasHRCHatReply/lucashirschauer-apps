---
name: retour
description: Retour d'expérience de fin de session, partagé entre les comptes via le dépôt orchestration-claude — type de tâche, modèle · effort choisis, verdict, montée éventuelle, le prompt (généralisé) qui a marché ou raté, la leçon. Alimente la synthèse commune. À utiliser en fin de session, quand on dit « /retour », « fais le retour », « partage les perfs », ou avant `/pause`.
---

# /retour — ce que cette session apprend aux autres

**Automatique depuis le 23/11/2026.** Le hook `verdict` demande ce retour une fois par session quand le cas apprend quelque chose
(plusieurs modèles, délégation, session fille, échec, correction, cas peu exemplifié, banque de moins de 50 retours). Il s'écrit alors
sans rien demander à l'utilisateur, avec `"source":"auto"`. L'utilisateur peut aussi taper `/retour` (`"source":"main"`).
Ces lignes nourrissent la fabrique de skills (`outils/candidats-skills.mjs`, passe d'affinage `outils/affinage.sh` tous les 2 jours).

Les chiffres (jetons, coût, modèles, agents) sont déjà relevés par `outils/extraire.mjs` (relu sur les transcriptions) et le hook `hooks/verdict.mjs`. Ce skill ajoute **ce que les chiffres ne disent pas** : est-ce que ça a marché, avec quel prompt, et faut-il changer la règle.

## Étapes

0. Le verdict est déjà calculé : le hook Stop `hooks/verdict.mjs` l'écrit à chaque fin de tour dans `~/.cache/orchestration/verdicts/<session>.json` (dernière série de tests, commits réussis, corrections, `verdict` et `critere`). Le reprendre pour la ligne de la session principale ; ne le changer que si la relecture le contredit, et dire pourquoi dans `ce_qui_a_rate`.
1. Relire la session et dresser **une ligne par tâche distincte** confiée à un modèle (la session elle-même, chaque agent, chaque session fille). Au plus 8 lignes.
2. Pour chaque ligne, remplir l'objet JSON ci-dessous. **Rien de confidentiel** : pas de nom de client, d'URL interne, de donnée personnelle ni de secret. Le prompt se **généralise** (« Relève toutes les différences de texte entre la capture A et B, format : tableau zone/source/cible ») ; jamais de copie brute.
3. Ajouter les lignes à `~/orchestration-claude/perfs/<compte>/retours.jsonl` (le compte est dans `perfs/.compte`), une ligne JSON par tâche.
4. Si une leçon vaut pour tout le monde (règle à changer, prompt réutilisable), l'écrire aussi dans `apprentissages/AAAA-MM-JJ-<conclusion>.md` (10 lignes au plus : constat, mesure, ce qu'on change).
5. Commiter et pousser :
   `cd ~/orchestration-claude && git add perfs apprentissages && git commit -m "perfs : retour <compte> <sujet>" && git pull --rebase && git push`
6. Dire en 2 lignes ce qui a été partagé.

## Format d'une ligne

```json
{"v":1,"date":"2026-10-22","compte":"ton-prenom","session":"30c03422","tache":"capture|extraction|code-script|code-bug|code-revue|code-refacto|redaction|classement|decision|orchestration|recherche|autre","role":"principal|agent|session-fille","modele":"haiku|sonnet|opus|fable|sol|terra|flash","effort":"low|medium|high|xhigh","verdict":"reussi|reussi-apres-correction|echec","montee":"aucune|prompt|modele|effort","critere":"comment on a vérifié (tests, comptage, relecture…)","prompt_generalise":"…","ce_qui_a_marche":"…","ce_qui_a_rate":"…","cause":"contexte|tache|contrainte|format|section|coordination|capacite|outil, seulement si le verdict n'est pas reussi","lecon":"une phrase, ou vide","skill":"nom de la skill de skills/metiers/ qui a servi, ou absent","source":"auto|main"}
```

## La cause d'un raté

Quand le verdict n'est pas `reussi`, `cause` dit quel composant du brief manquait, avec les mêmes valeurs que le vérificateur
(`skills/orchestrateur/agents/verificateur.md`, table « La cause d'un à reprendre ») : le reprendre du verdict noté (`verdicts.json`) s'il existe.
Les quatre premières causes relèvent de la famille « spécification » de l'étude MAST (https://arxiv.org/html/2503.13657v3), `coordination` du
« désalignement entre agents » ; `capacite` et `outil` sont hors du brief. La fabrique compte ces causes pour savoir quelle section d'une skill de
métier réécrire. En cas de doute, une cause du brief plutôt que `capacite`.

## Règles

- Le verdict s'appuie sur un critère objectif (test, comptage, relecture humaine), sinon `reussi` ne s'écrit pas : `n/a`.
- Ce skill est mécanique : Haiku · medium suffit ; ne pas lancer d'agent pour le faire.
