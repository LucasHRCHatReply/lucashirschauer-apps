export type Ligne = { genre: 'session' | 'agent'; nom: string; modele: string; effort: string; etat: 'travaille' | 'attend' | 'fini' | 'repos'; cout: number | null; message?: string }
export type Compte = { n: number; travaille: number; attend: number; fini: number; repos: number }
export type Etape = { texte: string; etat: 'pending' | 'in_progress' | 'completed' }
export type AgentVif = { id: string; description: string; modele: string; effort: string; fini: boolean }
export type Vif = { plan: Etape[]; activite: string | null; agents: AgentVif[]; delegations: number }
export type Prefs = { deplie: boolean; onboardingVu: boolean }
export type Instantane = {
  date: number
  erreur?: string
  ligne?: string   // ligne vivante du suivi sans modèle (outils/suivi.mjs), si son tableau a moins d’une minute
  titre?: string
  filles?: Compte
  agents?: Compte
  lignes?: Ligne[]
  synthese?: { enCours: number; finis: number; enAttente: number; rien: boolean }
  contexte?: { jetons: number | null; palier: string | null }
  cout?: number | null
  coutPartiel?: boolean
  stagiaire?: { en_cours: boolean; dernier: { modele?: string; type?: string; score?: number; interpretation?: string } | null; n7: number; accord7: number | null; fiables: string[] } | null
  attentes?: { n: number; items: { type: string; projet: string; message: string; depuis: string }[] }
  verdict?: { verdict: string; critere: string } | null
  prefs?: Prefs
}

declare module 'claude-code' {
  interface PluginState {
    'bandeau-orchestration': { instantane: Instantane | null; prefs: Prefs | null; vif: Vif | null }
  }
}
