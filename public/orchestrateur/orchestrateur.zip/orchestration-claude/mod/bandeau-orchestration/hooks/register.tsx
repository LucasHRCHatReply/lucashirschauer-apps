import { atom, read, update } from 'claude-code'
import type { Register } from 'claude-code'

import type { AgentVif, Etape, Instantane, Ligne, Prefs, Vif } from '../types'

// Le bandeau au-dessus de la saisie, replié par défaut : une pastille ; un clic déplie le détail.
// Chiffres : ~/orchestration-claude/mod/indicateurs-cli.mjs. Préférences (replié/déplié, bulle vue) :
// ~/.cache/orchestration/bandeau.json, écrit par mod/bandeau-etat.mjs.
const instantane = atom({ plugin: 'bandeau-orchestration', key: 'instantane' } as const, null)
const prefs = atom({ plugin: 'bandeau-orchestration', key: 'prefs' } as const, null)
// Ce que la session fait en direct, tiré des événements eux-mêmes (sans script) : le plan affiché, l'outil en cours,
// les agents lancés avec modèle · effort. Remplace le plugin whats-agent-doing.
const vif = atom({ plugin: 'bandeau-orchestration', key: 'vif' } as const, null)
const VIDE: Vif = { plan: [], activite: null, agents: [], delegations: 0 }

// Le plan de mcp__ccd_turn__update_plan : items (liste entière), advance, ou done/start (numéros à partir de 1).
export function appliquerPlan(plan: Etape[], e: any): Etape[] {
  if (Array.isArray(e.items)) return e.items.map((i: any) => ({ texte: String(i.content ?? ''), etat: i.status === 'completed' || i.status === 'in_progress' ? i.status : 'pending' }))
  const p = plan.map(x => ({ ...x }))
  if (e.advance) {
    const i = p.findIndex(x => x.etat === 'in_progress'); if (i >= 0) p[i].etat = 'completed'
    const j = p.findIndex(x => x.etat === 'pending'); if (j >= 0) p[j].etat = 'in_progress'
  }
  for (const n of Array.isArray(e.done) ? e.done : []) if (p[n - 1]) p[n - 1].etat = 'completed'
  if (typeof e.start === 'number' && p[e.start - 1]) { for (const x of p) if (x.etat === 'in_progress') x.etat = 'pending'; p[e.start - 1].etat = 'in_progress' }
  return p
}
// Ce qu'on lit de l'outil en cours, en deux mots plus son objet.
export function activite(e: any): string | null {
  const t = String(e.tool ?? '')
  if (t.startsWith('mcp__ccd_turn__') || t === 'ToolSearch') return null
  const base = (f: any) => String(f ?? '').split('/').pop()
  if (t === 'Bash') return `Commande · ${court(String(e.description || e.command || ''), 60)}`
  if (t === 'Read') return `Lecture · ${base(e.file_path)}`
  if (t === 'Edit' || t === 'Write') return `Écriture · ${base(e.file_path)}`
  if (t === 'Agent') return `Délégation · ${court(String(e.description ?? ''), 50)}`
  if (t.startsWith('mcp__')) return `Outil · ${t.split('__').slice(1).join(' ')}`
  return `Outil · ${t}`
}
// L'effort ne vient pas de agent.spawn : on le lit dans `deleguer.mjs … --effort x`, sinon dans la description « … · medium ».
export const effortDe = (s: string) => (s.match(/--effort[ =](\w+)/) || s.match(/·\s*(low|medium|high|xhigh|max)\b/i))?.[1]?.toLowerCase() ?? ''
const modeleCourt = (m: string) => (m.match(/(haiku|sonnet|opus|fable)[-\s]?(\d+)?[-.]?(\d+)?/i) ? m.replace(/^claude-/, '').replace(/-(\d+)-(\d+).*/, ' $1.$2') : m)

const MAX_LIGNES = 5
const PERIODE = 20_000
const MINIMUM = 8_000
const ETAT = { travaille: 'travaille', attend: 'attend', fini: 'fini', repos: 'au repos' } as const
const PUCE = { travaille: '●', attend: '▲', fini: '○', repos: '◐' } as const
// Jetons du design system « bandeau bento » (design/bandeau-bento/, Reply) : une couleur ne sert qu'au signal.
const C = { ciel: '#4bdcfe', bleu: '#009eff', succes: '#23cc99', erreur: '#de0c48', indigo: '#8f7dfa', bord: '#5c6d73', discret: '#41555b' } as const
const ACCENT = C.erreur
// Une tuile du bento : bordure ronde de 1 cellule, titre en petites capitales visuelles, contenu en colonne.
let UI: any = {}
function tuile(k: string, titre: string, couleur: string | undefined, enfants: any[], o: { grow?: number; width?: number; hover?: string } = {}) {
  const { Box, Text } = UI
  return (
    <Box key={k} borderStyle="round" borderColor={couleur ?? C.bord} paddingX={1} flexDirection="column" flexGrow={o.grow} width={o.width} hover={o.hover ? { scope: o.hover } : undefined}>
      <Text bold color={couleur} dimColor={!couleur}>{titre}</Text>
      {enfants}
    </Box>
  )
}

const dollars = (n: number | null | undefined, partiel?: boolean) =>
  n == null ? 'n/a' : `${partiel ? '≥ ' : ''}${n.toFixed(2).replace('.', ',')} $`
const kilo = (n: number | null | undefined) => (n == null ? 'n/a' : `${Math.round(n / 1000)} k`)
const court = (t: string, n: number) => (t.length > n ? `${t.slice(0, n - 1)}…` : t)

type Etat = { isEnCours: boolean; dernier: number; node: string | null; isPrefsLues: boolean }

// Lance un script du dossier mod/ avec node (le chemin de node varie selon la machine).
async function lancer($: any, st: Etat, script: string, args: string[]): Promise<string | null> {
  const home = (await $.env.get('HOME')) ?? ''
  const fichier = `${home}/orchestration-claude/${script}`
  const candidats = st.node ? [st.node] : [`${home}/.local/bin/node`, '/opt/homebrew/bin/node', '/usr/local/bin/node', 'node']
  for (const exe of candidats) {
    let res
    try { res = await $.process.run([exe, fichier, ...args], { timeoutMs: 25_000 }) } catch { continue }
    if (res.exitCode !== 0 || !res.stdout) continue
    st.node = exe
    return res.stdout
  }
  return null
}

async function rafraichir($: any, st: Etat, force = false) {
  const maintenant = await $.clock.now()
  if (st.isEnCours || (!force && maintenant - st.dernier < MINIMUM)) return
  st.isEnCours = true
  st.dernier = maintenant
  try {
    const session = (await $.env.get('CLAUDE_CODE_HOST_SESSION_ID')) ?? ''
    const out = await lancer($, st, 'mod/indicateurs-cli.mjs', session ? ['--session', session] : [])
    if (out === null) {
      await update($, instantane, () => ({ date: maintenant, erreur: 'Calcul impossible : node introuvable.' }))
      return
    }
    const data = JSON.parse(out) as Instantane
    await update($, instantane, () => data)
    // Les préférences se lisent une fois (le fichier est la vérité) ; ensuite l'écran les tient.
    if (!st.isPrefsLues && data.prefs) { st.isPrefsLues = true; await update($, prefs, () => data.prefs as Prefs) }
  } catch (err) {
    await update($, instantane, () => ({ date: maintenant, erreur: `Calcul impossible : ${String((err as Error).message).slice(0, 80)}` }))
  } finally {
    st.isEnCours = false
  }
}

async function garder($: any, st: Etat, cle: 'deplie' | 'onboardingVu', valeur: boolean) {
  await update($, prefs, (p: Prefs | null) => ({ deplie: false, onboardingVu: false, ...(p ?? {}), [cle]: valeur }))
  await lancer($, st, 'mod/bandeau-etat.mjs', ['set', cle, String(valeur)])
}

// Le bouton « Bureau » : outils/bureau.mjs ouvrir démarre le serveur de /sessiondesk s'il ne répond pas
// (un seul, repéré par son empreinte), puis ouvre la page de la session dans le navigateur par défaut.
async function ouvrirBureau($: any, st: Etat) {
  const session = (await $.env.get('CLAUDE_CODE_HOST_SESSION_ID')) ?? ''
  await lancer($, st, 'outils/bureau.mjs', ['ouvrir', ...(session ? ['--session', session] : [])])
}

export const register: Register = on => {
  const st: Etat = { isEnCours: false, dernier: 0, node: null, isPrefsLues: false }

  on('session.start', async ($, e, next) => {
    const started = await next(e)
    await $.command.register({ name: 'bandeau', description: 'Replie ou déplie le bandeau d’orchestration' })
    void rafraichir($, st, true)
    $.clock.every(PERIODE, () => { void rafraichir($, st, true) })
    return started
  })

  on('command.run', { command: 'bandeau' }, async $ => {
    const p = (await read($, prefs)) as Prefs | null
    const deplie = !(p?.deplie ?? false)
    await garder($, st, 'deplie', deplie)
    return { text: deplie ? 'Bandeau déplié.' : 'Bandeau replié.' }
  })

  on('prompt.submit', ($, e, next) => { void rafraichir($, st); return next(e) })
  on('tool.call', async ($, e, next) => {
    void rafraichir($, st)
    const x = e as any
    if (x.agentId) return next(e)   // un sous-agent : son activité ne remplace pas celle de la session
    if (x.tool === 'mcp__ccd_turn__update_plan') await update($, vif, (v: Vif | null) => ({ ...(v ?? VIDE), plan: appliquerPlan((v ?? VIDE).plan, x) }))
    const a = activite(x)
    if (a) await update($, vif, (v: Vif | null) => ({ ...(v ?? VIDE), activite: a, delegations: (v ?? VIDE).delegations + (x.tool === 'Agent' || /deleguer\.mjs/.test(String(x.command ?? '')) ? 1 : 0) }))
    try { return await next(e) } finally { if (a) await update($, vif, (v: Vif | null) => (v && v.activite === a ? { ...v, activite: null } : v)) }
  })

  on('agent.spawn', async ($, e, next) => {
    const r: any = await next(e)
    const x = e as any
    const ag: AgentVif = { id: String(r?.agentId ?? x.tool_use_id), description: String(x.description ?? x.subagentType ?? 'agent'), modele: modeleCourt(String(r?.model ?? x.model ?? 'n/a')), effort: effortDe(`${x.description ?? ''} ${x.prompt ?? ''}`.slice(0, 400)), fini: false }
    await update($, vif, (v: Vif | null) => ({ ...(v ?? VIDE), agents: [...(v ?? VIDE).agents.filter(a => a.id !== ag.id), ag].slice(-12) }))
    return r
  })
  on('classic.SubagentStop', async ($, e, next) => {
    const id = String((e as any).agent_id ?? '')
    await update($, vif, (v: Vif | null) => (v ? { ...v, agents: v.agents.map(a => (a.id === id ? { ...a, fini: true } : a)) } : v))
    return next(e)
  })
  on('turn.complete', ($, e, next) => { void rafraichir($, st, true); return next(e) })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const data = (await read($, instantane)) as Instantane | null
    const p = (await read($, prefs)) as Prefs | null
    const v: Vif = { ...VIDE, ...(((await read($, vif)) as Vif | null) ?? {}) }
    const iEtape = v.plan.findIndex(x => x.etat === 'in_progress')
    const faites = v.plan.filter(x => x.etat === 'completed').length
    const etape = v.plan.length ? (iEtape >= 0 ? `Étape ${iEtape + 1}/${v.plan.length} · ${court(v.plan[iEtape].texte, 50)}` : `${faites}/${v.plan.length} étapes faites`) : ''
    const agentsVifs = v.agents.filter(a => !a.fini)
    // Rien tant que les chiffres et les préférences ne sont pas lus ; rien sous une enquête.
    if (e.props.hasSurvey || data === null || p === null) return next(e)

    const { Box, Text, Button } = $.ui.resolve(e)
    UI = { Box, Text }
    const bascule = () => garder($, st, 'deplie', !p.deplie)

    if (data.erreur) return <Box><Text dimColor>Orchestration : {data.erreur}</Text></Box>

    const s = data.synthese!
    const base = data.ligne ? data.ligne : s.rien && !agentsVifs.length
      ? '◎ Orchestration · rien en cours'
      : `◎ Orchestration · ${Math.max(s.enCours, agentsVifs.length)} en cours${s.enAttente ? ` · ${s.enAttente} en attente` : ''}`
    const pastille = [base, etape].filter(Boolean).join(' · ')

    const bulle = !p.onboardingVu && (
      <Box borderStyle="round" paddingX={1} marginLeft={2}>
        <Text>Appuie ici pour voir le détail de l’orchestration : qui travaille, sur quel modèle, ce que ça coûte, ce qui t’attend.  </Text>
        <Button key="compris" label="Compris" variant="primary" onPress={() => garder($, st, 'onboardingVu', true)} />
      </Box>
    )

    const tete = (
      <Box>
        <Button key="pastille" label={`${pastille}  ${p.deplie ? '▾' : '▸'}`} plain onPress={bascule} />
        {bulle}
      </Box>
    )

    const L = e.props.bodyColumns
    const taille: 'large' | 'moyen' | 'etroit' = L >= 140 ? 'large' : L >= 80 ? 'moyen' : 'etroit'
    const direct = v.activite && <Box marginLeft={2}><Text dimColor>↳ {court(v.activite, Math.max(30, L - 6))}</Text></Box>
    if (!p.deplie) return direct ? <Box flexDirection="column">{tete}{direct}</Box> : tete

    // Le plan : la barre de segments (une case par étape) puis les lignes.
    const barre = (n: number) => v.plan.map((x, i) => (
      <Text key={`s${n}${i}`} color={x.etat === 'completed' ? C.succes : x.etat === 'in_progress' ? C.ciel : C.discret}>{'━━'}</Text>
    ))
    const lignesPlan = (larg: number) => v.plan.map((x, i) => (
      <Text key={`e${i}`} dimColor={x.etat === 'completed'} bold={x.etat === 'in_progress'} color={x.etat === 'in_progress' ? C.ciel : undefined}>{x.etat === 'completed' ? '✓' : x.etat === 'in_progress' ? '▸' : '·'} {i + 1}. {court(x.texte, Math.max(20, larg))}</Text>
    ))
    const titreEtape = v.plan.length ? (iEtape >= 0 ? `Étape ${iEtape + 1} / ${v.plan.length}` : `${faites} / ${v.plan.length} étapes faites`) : 'Plan'

    if (s.rien && !v.agents.length) {
      const planVu = v.plan.length > 0 && tuile('etape', titreEtape, C.ciel, [<Box key="b">{barre(0)}</Box>, ...lignesPlan(L - 12)])
      return <Box flexDirection="column">{tete}{direct}{planVu}<Box marginLeft={2}><Text dimColor>Cette session n’a lancé ni session fille ni agent pour l’instant.</Text></Box></Box>
    }

    const lignes: Ligne[] = data.lignes ?? []
    const vues = lignes.slice(0, MAX_LIGNES)
    const autres = lignes.length - vues.length
    const attendante = data.attentes?.items[0]
    const ligneAttente = lignes.find(l => l.etat === 'attend' && l.message)
    const messageAttente = attendante ? `${attendante.projet ? `${attendante.projet} : ` : ''}${attendante.message}` : ligneAttente ? `${ligneAttente.nom} : ${ligneAttente.message}` : ''
    const nAttente = Math.max(s.enAttente, messageAttente ? 1 : 0)

    const expl: Record<string, string> = {
      cours: `Sessions filles et agents qui travaillent maintenant : ${s.enCours}.`,
      finis: `Sessions filles et agents terminés : ${s.finis}.`,
      attente: nAttente ? `Ce qui attend une réponse de vous : ${nAttente}.` : 'Rien n’attend une réponse de vous.',
      ctx: `Poids du contexte de cette session : ${data.contexte?.jetons ?? 'n/a'} jetons${data.contexte?.palier ? `, palier ${data.contexte.palier}` : ''} ; compression à 180 k.`,
      cout: `Coût de la session, de ses filles et de ses agents${data.coutPartiel ? ' (au moins : certains coûts manquent)' : ''}.`,
    }
    const texteBureau = 'Ouvre le bureau : qui travaille, ce que chacun a fait, ce que ça coûte'

    // Tuile « En attente » : rouge, en tête dès que la fenêtre rétrécit, absente s'il n'y a rien.
    const tAttente = (larg: number) => nAttente > 0 && tuile('attente', `En attente · ${nAttente}`, C.erreur, [
      <Text key="m">▲ {court(messageAttente || 'une réponse est attendue', Math.max(20, larg))}</Text>,
    ], { hover: 'attente' })

    // Tuile principale « Étape n/N ».
    const tEtape = (larg: number, grow = 1) => tuile('etape', titreEtape, C.ciel, [
      ...(v.plan.length ? [<Box key="b">{barre(1)}</Box>, ...lignesPlan(larg)] : [<Text key="r" dimColor>Aucun plan affiché.</Text>]),
      ...(direct ? [<Text key="d" dimColor>↳ {court(v.activite ?? '', Math.max(20, larg))}</Text>] : []),
    ], { grow })

    // Tuile « Qui travaille » : sessions filles puis agents de la session, modèle · effort.
    const ligneQui = (larg: number) => [
      ...vues.map((l, i) => (
        <Box key={`l${i}`} hover={{ scope: `l${i}` }}>
          <Text color={l.etat === 'attend' ? C.erreur : l.etat === 'travaille' ? C.succes : undefined} dimColor={l.etat === 'fini' || l.etat === 'repos'}>{PUCE[l.etat]} </Text>
          <Box flexGrow={1}><Text dimColor={l.etat === 'fini'}>{court(l.nom, Math.max(12, larg - 30))}</Text></Box>
          <Text color={C.indigo}> {l.modele}{l.effort ? ` · ${l.effort}` : ''}</Text>
          <Text dimColor> {dollars(l.cout)}</Text>
        </Box>
      )),
      ...(autres > 0 ? [<Text key="autres" dimColor>+ {autres} autre{autres > 1 ? 's' : ''}</Text>] : []),
      ...v.agents.slice(-MAX_LIGNES).map(a => (
        <Box key={`a-${a.id}`}>
          <Text color={a.fini ? undefined : C.succes} dimColor={a.fini}>{a.fini ? PUCE.fini : PUCE.travaille} </Text>
          <Box flexGrow={1}><Text dimColor={a.fini}>{court(a.description, Math.max(12, larg - 24))}</Text></Box>
          <Text color={C.indigo}> {a.modele}{a.effort ? ` · ${a.effort}` : ''}</Text>
        </Box>
      )),
      ...(data.stagiaire ? [(() => { const g = data.stagiaire!; const m = (g.dernier?.modele || '').replace(/^hf\.co\/LiquidAI\//, '').replace(/-GGUF.*$/, '').split(':')[0]; return (
        <Box key="stag" hover={{ scope: 'stag' }}>
          <Text color={g.en_cours ? C.succes : undefined} dimColor={!g.en_cours}>◐ </Text>
          <Box flexGrow={1}><Text dimColor>Stagiaire{g.en_cours ? ' · rejoue' : ''}</Text></Box>
          <Text dimColor> {m || 'local'}{g.accord7 != null ? ` · accord ${Math.round(g.accord7 * 100)} % sur ${g.n7}` : ''}</Text>
        </Box>) })()] : []),
      ...(v.agents.length ? [<Text key="deleg" dimColor>Agents de cette session · {v.delegations} délégation{v.delegations > 1 ? 's' : ''}</Text>] : []),
    ]
    const nQui = Math.max(s.enCours, agentsVifs.length)
    const tQui = (larg: number, grow = 1) => tuile('qui', `Qui travaille · ${nQui}`, undefined, ligneQui(larg), { grow })

    // Chiffres : contexte (jauge vers 180 k, rouge au-delà de 75 %), coût, compteurs.
    const jetons = data.contexte?.jetons ?? null
    const part = jetons == null ? 0 : Math.min(1, jetons / 180_000)
    const jauge = (n: number) => {
      const plein = Math.round(part * n)
      return <Box key="j"><Text color={part > 0.75 ? C.erreur : C.bleu}>{'█'.repeat(plein)}</Text><Text color={C.discret}>{'░'.repeat(n - plein)}</Text></Box>
    }
    const tCtx = tuile('ctx', 'Contexte', undefined, [<Text key="v" bold>{kilo(jetons)}</Text>, jauge(14)], { hover: 'ctx', width: 20 })
    const tCout = tuile('cout', 'Coût', undefined, [<Text key="v" bold>{dollars(data.cout, data.coutPartiel)}</Text>, <Text key="d" dimColor>session + agents</Text>], { hover: 'cout', width: 20 })
    const compteurs = (
      <Box key="compteurs" gap={2} marginLeft={1}>
        <Box hover={{ scope: 'cours' }}><Text dimColor>En cours </Text><Text bold>{s.enCours}</Text></Box>
        <Box hover={{ scope: 'finis' }}><Text dimColor>Finis </Text><Text bold>{s.finis}</Text></Box>
        {nAttente === 0 && <Box hover={{ scope: 'attente' }}><Text dimColor>En attente </Text><Text bold>0</Text></Box>}
        <Box hover={{ scope: 'bureau' }}><Button key="bureau" plain label="Bureau ↗" onPress={() => ouvrirBureau($, st)} /></Box>
      </Box>
    )

    const survol = [
      ...Object.keys(expl).map(id => ({ scope: id, texte: expl[id] })),
      { scope: 'bureau', texte: texteBureau },
      ...(data.stagiaire ? [{ scope: 'stag', texte: `Stagiaire local (Mac mini) : refait en ombre les tâches simples des agents Haiku et compare. ${data.stagiaire.dernier?.interpretation || ''}${data.stagiaire.fiables.length ? ` Fiable proposé pour : ${data.stagiaire.fiables.join(', ')}.` : ''}`.trim() }] : []),
      ...vues.map((l, i) => ({ scope: `l${i}`, texte: `${l.nom} — ${l.genre === 'agent' ? 'agent' : 'session fille'}, ${l.modele}${l.effort ? ` · ${l.effort}` : ''}, ${ETAT[l.etat]}.` })),
    ]
    const barreSurvol = (
      <Box key="survol" height={1} marginLeft={2}>
        <Text dimColor> </Text>
        {survol.map(x => (
          <Box key={`x-${x.scope}`} position="absolute" top={0} left={0} display="none" hover={{ scope: x.scope, display: 'flex' }}>
            <Text dimColor>{court(x.texte, Math.max(40, L - 4))}</Text>
          </Box>
        ))}
      </Box>
    )

    // Large (140 colonnes et plus) : Étape | En attente + Qui travaille | chiffres.
    if (taille === 'large') {
      const col = Math.floor((L - 26) / 2) - 6
      return (
        <Box flexDirection="column">
          {tete}
          <Box gap={1}>
            {tEtape(col)}
            <Box flexDirection="column" flexGrow={1}>{tAttente(col)}{tQui(col)}</Box>
            <Box flexDirection="column">{tCtx}{tCout}</Box>
          </Box>
          {compteurs}
          {barreSurvol}
        </Box>
      )
    }
    // Moyen (80 à 140) : En attente en tête sur toute la largeur, puis Étape | chiffres, puis Qui travaille.
    if (taille === 'moyen') {
      return (
        <Box flexDirection="column">
          {tete}
          {tAttente(L - 12)}
          <Box gap={1}>{tEtape(L - 34)}<Box flexDirection="column">{tCtx}{tCout}</Box></Box>
          {tQui(L - 8)}
          {compteurs}
          {barreSurvol}
        </Box>
      )
    }
    // Étroit (moins de 80) : une seule colonne ; les chiffres se replient en une ligne de puces.
    return (
      <Box flexDirection="column">
        {tete}
        {tAttente(L - 10)}
        {tEtape(L - 10)}
        <Box marginLeft={1} gap={2}>
          <Box hover={{ scope: 'ctx' }}><Text dimColor>Contexte </Text><Text bold color={part > 0.75 ? C.erreur : undefined}>{kilo(jetons)}</Text></Box>
          <Box hover={{ scope: 'cout' }}><Text dimColor>Coût </Text><Text bold>{dollars(data.cout, data.coutPartiel)}</Text></Box>
        </Box>
        {tQui(L - 8)}
        {compteurs}
        {barreSurvol}
      </Box>
    )
  })
}
