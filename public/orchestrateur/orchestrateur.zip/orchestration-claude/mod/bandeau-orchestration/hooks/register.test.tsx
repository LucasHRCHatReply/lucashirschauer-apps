import { expect, test } from 'claude-code/testing'

const BAND = { plugin: 'bandeau-orchestration', component: 'AbovePrompt', props: { hasSurvey: false, isWorking: false, maxRows: 20, bodyColumns: 120 } } as const
const ligne = (nom: string, etat: string, message = '') => ({ genre: 'agent', nom, modele: 'sonnet 5.5', effort: 'medium', etat, cout: 0.5, message })
const DATA = {
  date: 1, titre: 'T', filles: { n: 1, travaille: 0, attend: 1, fini: 0, repos: 0 }, agents: { n: 7, travaille: 3, attend: 0, fini: 4, repos: 0 },
  lignes: [ligne('Fille qui attend', 'attend', 'Quelle option ?'), ligne('Agent un', 'travaille'), ligne('Agent deux', 'travaille'), ligne('Agent trois', 'travaille'), ligne('Agent fini un', 'fini'), ligne('Agent fini deux', 'fini'), ligne('Agent fini trois', 'fini'), ligne('Agent fini quatre', 'fini')],
  synthese: { enCours: 3, finis: 4, enAttente: 1, rien: false },
  contexte: { jetons: 247282, palier: null }, cout: 34.21, coutPartiel: false, attentes: { n: 0, items: [] }, verdict: null,
}
const RIEN = { ...DATA, lignes: [], synthese: { enCours: 0, finis: 0, enAttente: 0, rien: true } }

function monte(on: any, data: any, prefs: any, vif: any = null) {
  on('ui.render', ($: any, e: any) => { const { Text } = $.ui.resolve(e); return <Text>engine</Text> })
  on('state.get', (_: any, e: any) => ({ value: { value: e.key === 'instantane' ? data : e.key === 'vif' ? vif : prefs, version: 1 } }))
}
const textes = async (ui: any) => (await ui.findAll?.({ type: 'Text' }))?.map((t: any) => t.text).join('|') ?? ''

test('replié par défaut : une seule pastille, ni compteurs ni tableau', async ($, on) => {
  monte(on, DATA, { deplie: false, onboardingVu: true })
  for (const surface of ['terminal', 'desktop'] as const) {
    const ui = await $.ui.mount({ ...BAND, surface })
    expect(String((await ui.find({ type: 'Button', key: 'pastille' }))?.props?.label)).toMatch(/◎ Orchestration · 3 en cours · 1 en attente/)
    expect(await ui.find({ type: 'Text', text: /Contexte/ })).toBeUndefined()
    expect(await ui.find({ type: 'Text', text: /Agent un/ })).toBeUndefined()
    expect(await ui.find({ type: 'Button', key: 'bureau' })).toBeUndefined()
    await ui.unmount()
  }
})

test('déplié : compteurs, lignes qui attendent d’abord, 5 lignes puis « + n autres »', async ($, on) => {
  monte(on, DATA, { deplie: true, onboardingVu: true })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  for (const re of [/En cours/, /Finis/, /En attente/, /Contexte/, /247 k/, /34,21 \$/, /Fille qui attend/, /Quelle option/, /\+ 3 autres/]) {
    expect((await ui.find({ type: 'Text', text: re }))?.text).toBeDefined()
  }
  expect(String((await ui.find({ type: 'Button', key: 'bureau' }))?.props?.label)).toBe('Bureau ↗')
  expect(await ui.find({ type: 'Text', text: /Agent fini deux/ })).toBeUndefined()   // au-delà de 5 lignes
  await ui.unmount()
})

test('rien en cours : la pastille et le détail le disent', async ($, on) => {
  monte(on, RIEN, { deplie: true, onboardingVu: true })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  expect(String((await ui.find({ type: 'Button', key: 'pastille' }))?.props?.label)).toMatch(/◎ Orchestration · rien en cours/)
  expect((await ui.find({ type: 'Text', text: /n’a lancé ni session fille ni agent/ }))?.text).toBeDefined()
  expect(await ui.find({ type: 'Text', text: /Finis/ })).toBeUndefined()
  await ui.unmount()
})

test('bulle d’accueil : présente tant qu’elle n’est pas vue, absente ensuite', async ($, on) => {
  monte(on, DATA, { deplie: false, onboardingVu: false })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  expect((await ui.find({ type: 'Text', text: /Appuie ici pour voir le détail/ }))?.text).toBeDefined()
  expect(await ui.find({ type: 'Button', key: 'compris' })).toBeDefined()
  await ui.unmount()
})

test('bulle d’accueil vue : jamais redessinée', async ($, on) => {
  monte(on, DATA, { deplie: false, onboardingVu: true })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  expect(await ui.find({ type: 'Text', text: /Appuie ici/ })).toBeUndefined()
  await ui.unmount()
})

test('préférences pas encore lues : rien n’est dessiné par le bandeau', async ($, on) => {
  monte(on, DATA, null)
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  expect((await ui.find({ type: 'Text' }))?.text).toBe('engine')
  await ui.unmount()
})

test('le clic sur Bureau lance bureau.mjs ouvrir avec la session', async ($, on) => {
  monte(on, DATA, { deplie: true, onboardingVu: true })
  const appels: string[][] = []
  on('env.get', (_: any, e: any) => ({ value: e.name === 'HOME' ? '/h' : 'local_abc' }))
  on('process.run', (_: any, e: any) => { appels.push(e.argv); return { value: { exitCode: 0, stdout: 'ok', stderr: '' } } })
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  await ui.press({ key: 'bureau' })
  expect(appels.some(a => a.includes('/h/orchestration-claude/outils/bureau.mjs') && a.includes('ouvrir') && a.includes('--session') && a.includes('local_abc'))).toBe(true)
  await ui.unmount()
})

const VIF = {
  plan: [{ texte: 'Lire le code', etat: 'completed' }, { texte: 'Brancher le bandeau', etat: 'in_progress' }, { texte: 'Commiter', etat: 'pending' }],
  activite: 'Commande · Lancer les tests', delegations: 2,
  agents: [{ id: 'a1', description: 'Relever les écarts', modele: 'sonnet 5.5', effort: 'medium', fini: false }, { id: 'a2', description: 'Vérifier le CHANGELOG', modele: 'haiku 5.5', effort: 'low', fini: true }],
}

test('replié : l’étape n/N du plan et l’activité en direct', async ($, on) => {
  monte(on, DATA, { deplie: false, onboardingVu: true }, VIF)
  const ui = await $.ui.mount({ ...BAND, surface: 'terminal' })
  expect(String((await ui.find({ type: 'Button', key: 'pastille' }))?.props?.label)).toMatch(/Étape 2\/3 · Brancher le bandeau/)
  expect((await ui.find({ type: 'Text', text: /↳ Commande · Lancer les tests/ }))?.text).toBeDefined()
  await ui.unmount()
})

test('déplié : le plan entier et les agents avec modèle · effort', async ($, on) => {
  monte(on, RIEN, { deplie: true, onboardingVu: true }, VIF)
  const ui = await $.ui.mount({ ...BAND, surface: 'desktop' })
  for (const re of [/✓ 1\. Lire le code/, /▸ 2\. Brancher le bandeau/, /· 3\. Commiter/, /2 délégations/, /Relever les écarts/, /sonnet 5\.5 · medium/, /haiku 5\.5 · low/]) {
    expect((await ui.find({ type: 'Text', text: re }))?.text).toBeDefined()
  }
  await ui.unmount()
})

for (const L of [60, 100, 160]) {
  test(`bento à ${L} colonnes : attente, étape, contexte, coût et Bureau restent visibles`, async ($, on) => {
    monte(on, DATA, { deplie: true, onboardingVu: true }, VIF)
    const ui = await $.ui.mount({ ...BAND, props: { ...BAND.props, bodyColumns: L }, surface: 'terminal' })
    for (const re of [/En attente · /, /Étape 2 \/ 3/, /Contexte/, /247 k/, /34,21 \$/, /Qui travaille/]) {
      expect((await ui.find({ type: 'Text', text: re }))?.text).toBeDefined()
    }
    expect(String((await ui.find({ type: 'Button', key: 'bureau' }))?.props?.label)).toBe('Bureau ↗')
    await ui.unmount()
  })
}
