#!/usr/bin/env node
// Audit d'un dossier de règles chargé à chaque session (P14, P16), en lecture seule.
//   node outils/audit-config.mjs <dossier> [--coffre <racine>] [--plafond 24400] [--ignorer mot,mot] [--json]
// --ignorer : mots propres au coffre (prénom, projet) à ne pas compter dans les doublons.
// <dossier> : le dossier de mémoire (une règle par fichier .md, l'index MEMORY.md). --coffre : où chercher les
// cibles des liens [[…]] (par défaut le parent du dossier).
// Cinq constats, chacun avec sa liste :
//   1. poids de l'index face au plafond (au-delà, la fin n'est pas chargée) et lignes de plus de 200 caractères ;
//   2. règles d'un seul projet listées dans l'index chargé partout (portee:/projet: ou nom du projet dans la description) ;
//   3. liens [[…]] morts (aucun fichier de ce nom dans le coffre) ;
//   4. doublons probables (descriptions proches, Jaccard ≥ 0,5 sur les mots de plus de 3 lettres) ;
//   5. règles qui décrivent une procédure (≥ 4 étapes numérotées ou ≥ 2 blocs de commande shell) : candidates skill.
// Plus : fichiers absents de l'index, entrées d'index sans fichier. Code 0 toujours : un audit propose, il ne bloque pas.
import fs from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i < 0 ? d : args[i + 1]; };
const dossier = args.find((a, i) => !a.startsWith('--') && !['--coffre', '--plafond', '--ignorer'].includes(args[i - 1]));
if (!dossier || !fs.existsSync(dossier)) { console.error('usage : node outils/audit-config.mjs <dossier> [--coffre <racine>] [--plafond 24400] [--json]'); process.exit(2); }
const COFFRE = opt('coffre', path.dirname(path.resolve(dossier)));
const PLAFOND = +opt('plafond', 24400);
const TRANSVERSAL = /^(transversale?|tous|commun|global)$/i;

function frontmatter(t) {
  const m = t.match(/^---\n([\s\S]*?)\n---\n?/); if (!m) return [{}, t];
  const o = {}; for (const l of m[1].split('\n')) { const k = l.match(/^\s*([\w-]+):\s*(.*)$/); if (k) o[k[1]] = k[2].replace(/^"|"$/g, ''); }
  return [o, t.slice(m[0].length)];
}
function basenames(racine) {
  const s = new Set(); const pile = [racine];
  while (pile.length) { const d = pile.pop(); let e; try { e = fs.readdirSync(d, { withFileTypes: true }); } catch { continue; }
    for (const x of e) { if (x.name.startsWith('.') || x.name === 'node_modules') continue; const f = path.join(d, x.name);
      if (x.isDirectory()) pile.push(f); else s.add(x.name.replace(/\.[^.]+$/, '')); } }
  return s;
}
const IGNORES = new Set(['dans', 'pour', 'avec', 'sans', 'veut', 'doit', 'faut', 'quand', 'chantier', 'page', 'plus', 'tout', 'toute', ...String(opt('ignorer', '')).toLowerCase().split(',').filter(Boolean)]);
const mots = (t) => new Set((t.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').match(/[a-z]{4,}/g) || []).filter((m) => !IGNORES.has(m)));
const jaccard = (a, b) => { const i = [...a].filter((x) => b.has(x)).length; return i / (a.size + b.size - i || 1); };

export function auditer(dir) {
  const fichiers = fs.readdirSync(dir).filter((f) => f.endsWith('.md') && f !== 'MEMORY.md').sort();
  const index = fs.existsSync(path.join(dir, 'MEMORY.md')) ? fs.readFileSync(path.join(dir, 'MEMORY.md'), 'utf8') : '';
  const octets = Buffer.byteLength(index);
  const lignes = index.split('\n');
  let cumul = 0, coupe = null;
  lignes.forEach((l, i) => { cumul += Buffer.byteLength(l) + 1; if (coupe === null && cumul > PLAFOND) coupe = i + 1; });
  const entrees = [...index.matchAll(/\]\(([^)]+\.md)\)/g)].map((m) => m[1]);
  const regles = fichiers.map((f) => { const t = fs.readFileSync(path.join(dir, f), 'utf8'); const [fm, corps] = frontmatter(t); return { f, nom: f.replace(/\.md$/, ''), fm, corps, desc: fm.description || '' }; });
  const projets = [...new Set(regles.map((r) => r.fm.portee || r.fm.projet).filter((p) => p && !TRANSVERSAL.test(p)))];

  const unProjet = regles.filter((r) => entrees.includes(r.f)).flatMap((r) => {
    const p = r.fm.portee || r.fm.projet;
    if (p && !TRANSVERSAL.test(p)) return [{ regle: r.nom, projet: p, par: 'frontmatter' }];
    if (p) return [];
    const cite = projets.find((x) => new RegExp(`\\b${x}\\b`, 'i').test(r.desc));
    return cite ? [{ regle: r.nom, projet: cite, par: 'description' }] : [];
  });

  const connus = basenames(COFFRE);
  const sansCode = (t) => t.replace(/```[\s\S]*?```/g, '').replace(/`[^`\n]*`/g, '');
  const morts = regles.flatMap((r) => [...sansCode(r.corps).matchAll(/\[\[([^\]|#]+)(?:[|#][^\]]*)?\]\]/g)].map((m) => m[1].trim()).filter((c) => !connus.has(c)).map((c) => ({ regle: r.nom, lien: c })));

  const doublons = [];
  const ens = regles.map((r) => mots(r.desc + ' ' + r.nom.replace(/-/g, ' ')));
  for (let i = 0; i < regles.length; i++) for (let j = i + 1; j < regles.length; j++) {
    const s = jaccard(ens[i], ens[j]); if (s >= 0.5) doublons.push({ a: regles[i].nom, b: regles[j].nom, jaccard: +s.toFixed(2) });
  }

  const procedures = regles.flatMap((r) => {
    const etapes = (r.corps.match(/^\s*\d+[.)]\s+\S/gm) || []).length, blocs = (r.corps.match(/^```(?:bash|sh|zsh|shell)?\n\s*(?:\$\s*)?(?:node|npm|git|cd|ssh|rg|grep|curl|python3?|\.?\/|~\/)/gm) || []).length;
    return etapes >= 4 || blocs >= 2 ? [{ regle: r.nom, etapes, blocs_commande: blocs, octets: Buffer.byteLength(r.corps) }] : [];
  });

  return {
    dossier: dir, regles: regles.length,
    index: { octets, plafond: PLAFOND, depasse: octets > PLAFOND, premiere_ligne_coupee: coupe, lignes: lignes.length,
      lignes_trop_longues: lignes.map((l, i) => ({ ligne: i + 1, longueur: [...l].length })).filter((x) => x.longueur > 200) },
    un_projet: unProjet, un_projet_octets: lignes.filter((l) => unProjet.some((u) => l.includes(`(${u.regle}.md)`))).reduce((s, l) => s + Buffer.byteLength(l) + 1, 0),
    liens_morts: morts, doublons, procedures,
    hors_index: fichiers.filter((f) => !entrees.includes(f)), index_sans_fichier: entrees.filter((e) => !fichiers.includes(e)),
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const a = auditer(dossier);
  if (args.includes('--json')) { console.log(JSON.stringify(a, null, 1)); process.exit(0); }
  const ko = (n) => (n ? '⚠' : '✓');
  console.log(`Audit de ${a.dossier} : ${a.regles} règles.`);
  console.log(`${ko(a.index.depasse)} index ${a.index.octets} octets pour un plafond de ${a.index.plafond}${a.index.depasse ? ` : coupé à partir de la ligne ${a.index.premiere_ligne_coupee} sur ${a.index.lignes}` : ''} · ${a.index.lignes_trop_longues.length} lignes de plus de 200 caractères`);
  console.log(`${ko(a.un_projet.length)} ${a.un_projet.length} règles d'un seul projet dans l'index chargé partout (${a.un_projet_octets} octets d'index) : ${Object.entries(a.un_projet.reduce((o, u) => ((o[u.projet] = (o[u.projet] || 0) + 1), o), {})).map(([p, n]) => `${p} ${n}`).join(', ') || '-'}`);
  console.log(`${ko(a.liens_morts.length)} ${a.liens_morts.length} liens [[…]] morts${a.liens_morts.length ? ' : ' + a.liens_morts.slice(0, 12).map((m) => `${m.regle} → ${m.lien}`).join(' ; ') : ''}`);
  console.log(`${ko(a.doublons.length)} ${a.doublons.length} doublons probables${a.doublons.length ? ' : ' + a.doublons.map((d) => `${d.a} ≈ ${d.b} (${d.jaccard})`).join(' ; ') : ''}`);
  console.log(`${ko(a.procedures.length)} ${a.procedures.length} règles qui décrivent une procédure (candidates skill)${a.procedures.length ? ' : ' + a.procedures.map((p) => `${p.regle} (${p.etapes} étapes, ${p.blocs_commande} blocs)`).join(' ; ') : ''}`);
  console.log(`${ko(a.hors_index.length)} ${a.hors_index.length} fichiers hors index${a.hors_index.length ? ' : ' + a.hors_index.join(', ') : ''} · ${a.index_sans_fichier.length} entrées sans fichier${a.index_sans_fichier.length ? ' : ' + a.index_sans_fichier.join(', ') : ''}`);
}
