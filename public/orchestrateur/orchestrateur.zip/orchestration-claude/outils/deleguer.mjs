#!/usr/bin/env node
// deleguer : l'orchestratrice Claude confie une tâche à GPT (codex), Gemini (agy) ou une fille Claude (claude -p), sur les
// abonnements, et note le résultat dans le journal intermodèle (lu par outils/intermodele.mjs, le bureau et /orch modeles).
// Les recettes d'appel sont celles, éprouvées, de ~/pboard/outils/multimodele-mcp/bancv1/moteur.py (commande(), lire(), préambules).
//
// Usage : node outils/deleguer.mjs --a gpt|gemini|claude --modele <id> --effort low|medium|high|xhigh
//           --mode texte|fichiers|web|image|lecture --dossier <chemin> [--brief f.md | --prompt "…"] [--reference image.png]
//           [--delai 600] [--tache <id>] [--type code|veille|image|donnees|relecture|redaction] [--a-sec]
// Sortie : un JSON sur stdout {ok, texte, fichiers, jetons, duree_s, quota_avant, quota_apres, erreur, …}. Code de sortie : 0 ok, 1 échec,
//          2 mauvais arguments, 3 refus ou limite de quota (jamais un échec de la tâche).
// Environnement : DELEGUER_AGY, DELEGUER_CODEX, DELEGUER_CLAUDE (binaires), DELEGUER_BRAIN (images Gemini), ORCH_INTERMODELE (journal),
//                 DELEGUER_SANS_JAUGES=1 (tests : ne lit aucune jauge).
// Aucune clé, aucun jeton n'est lu : les clés d'API de l'environnement sont retirées de l'appel pour rester sur l'abonnement.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { assainir, compteLocal } from './intermodele.mjs';

const BIN = {
  gemini: () => process.env.DELEGUER_AGY || '/Applications/Gemini.app/Contents/Helpers/agy',
  gpt: () => process.env.DELEGUER_CODEX || '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
  claude: () => process.env.DELEGUER_CLAUDE || 'claude',
};
const FOURNISSEURS = ['gpt', 'gemini', 'claude'];
const EFFORTS = ['low', 'medium', 'high', 'xhigh'];
const MODES = ['texte', 'fichiers', 'web', 'image', 'lecture'];
const TYPES = ['code', 'veille', 'image', 'donnees', 'relecture', 'redaction'];
// Seuils de refus (brief) : Gemini 5 h < 25 % ou semaine < 30 % restant ; Codex semaine > 70 % ; Codex 5 h > 85 %.
export const SEUILS = { gemini_5h_reste_min: 25, gemini_semaine_reste_min: 30, gpt_semaine_max: 70, gpt_5h_max: 85 };

// Préambules par mode (moteur.py, sans accents comme dans le banc) ; « image » est ajouté pour cet outil.
export const PREAMBULE = {
  web: "Utilise la recherche web pour trouver et verifier l'information (elle est autorisee et attendue). Ne cree aucun fichier. Reponds directement, en citant l'URL exacte de chaque source. ",
  lecture: 'Lis les fichiers fournis dans le dossier courant (chemins relatifs). Ne cree aucun fichier et ne lance aucune commande shell. Reponds directement dans ta reponse. ',
  web_agy: "Utilise uniquement ton outil integre de recherche web Google. N'utilise jamais le terminal, ni curl, ni aucune commande. Ne cree aucun fichier. Reponds directement, en citant l'URL exacte de chaque source. ",
  texte: "N'utilise aucun outil, ne cree aucun fichier : reponds directement dans ta reponse. ",
  fichiers: 'Ecris le ou les fichiers demandes dans le dossier courant (chemins relatifs). Ne lance aucune commande shell. Ta reponse finale : une ligne qui liste les fichiers ecrits. ',
  image: "Genere l'image demandee avec ton outil integre de generation d'image. Si un nom de fichier est indique, enregistre l'image dans le dossier courant sous ce nom. Reponds en une phrase. ",
};

export function commande(p, m, e, prompt, mode, images = []) {
  const bin = BIN[p]();
  if (p === 'claude') {
    const c = [bin, '-p', prompt, '--model', m, '--effort', e, '--output-format', 'json', '--setting-sources', 'project', '--strict-mcp-config'];
    if (mode === 'texte') c.push('--tools', '');
    else if (mode === 'web') c.push('--tools', 'WebSearch,WebFetch', '--allowedTools', 'WebSearch,WebFetch');
    else if (mode === 'lecture') c.push('--tools', 'Read', '--allowedTools', 'Read');
    else c.push('--tools', 'Read,Write,Edit', '--permission-mode', 'acceptEdits');
    return c;
  }
  if (p === 'gpt') {
    const c = [bin, ...(mode === 'web' ? ['--search'] : []), 'exec', '--skip-git-repo-check', '--ephemeral', '--json', '-s', mode === 'fichiers' || mode === 'image' ? 'workspace-write' : 'read-only', '-m', m, '-c', `model_reasoning_effort=${e}`];
    for (const i of images) c.push('--image', i);
    return [...c, ...(images.length ? ['--'] : []), prompt];
  }
  const c = [bin, '-p', prompt, '--model', `${m}-${e}`, '--output-format', 'json'];
  if (mode === 'fichiers' || mode === 'image') c.push('--mode', 'accept-edits');
  else if (mode === 'lecture') c.push('--mode', 'auto'); // web : sans --mode (search_web passe, essai du 06/11)
  return c;
}

const jsonDepuis = (out) => JSON.parse(out.slice(out.indexOf('{')));
export function lire(p, out) {
  const r = { texte: '', entree: 0, cache: 0, sortie: 0, raisonnement: 0 };
  if (p === 'claude') {
    const j = jsonDepuis(out), u = j.usage || {};
    Object.assign(r, { texte: j.result || '', entree: (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0), cache: u.cache_read_input_tokens || 0, sortie: u.output_tokens || 0, erreurModele: !!j.is_error });
  } else if (p === 'gpt') {
    for (const l of out.split('\n')) {
      if (!l.startsWith('{')) continue;
      let j; try { j = JSON.parse(l); } catch { continue; }
      if (j.type === 'item.completed' && j.item?.type === 'agent_message') r.texte = j.item.text;
      if (j.type === 'turn.completed') { const u = j.usage || {}; Object.assign(r, { entree: (u.input_tokens || 0) - (u.cached_input_tokens || 0), cache: u.cached_input_tokens || 0, sortie: u.output_tokens || 0, raisonnement: u.reasoning_output_tokens || 0 }); }
    }
  } else {
    const j = jsonDepuis(out), u = j.usage || {};
    Object.assign(r, { texte: j.response || '', entree: (u.input_tokens || 0) - (u.cache_read_tokens || 0), cache: u.cache_read_tokens || 0, sortie: u.output_tokens || 0, raisonnement: u.thinking_tokens || 0 });
  }
  return r;
}

// Une limite d'abonnement n'est jamais un échec de la tâche.
const LIMITE = /weekly limit|usage limit|hit your (?:usage )?limit|limit reached|rate.?limit|\b429\b|AuthRequired|Transport channel closed|quota/i;

// ── Exécution bornée en Node (pas de commande timeout) : stdin fermé, délai, arrêt du groupe de processus.
export function executer(argv, { cwd, delai = 600, env = process.env, entree = null } = {}) {
  return new Promise((resolve) => {
    let out = '', err = '', fini = false, tue = false;
    const [bin, ...args] = argv;
    const ch = spawn(bin, args, { cwd, env, stdio: [entree == null ? 'ignore' : 'pipe', 'pipe', 'pipe'], detached: true });
    const fin = (r) => { if (!fini) { fini = true; clearTimeout(t); resolve({ out, err, ...r }); } };
    const t = setTimeout(() => { tue = true; try { process.kill(-ch.pid, 'SIGKILL'); } catch { try { ch.kill('SIGKILL'); } catch { /* déjà fini */ } } fin({ code: null, delaiDepasse: true }); }, delai * 1000);
    ch.stdout.on('data', (d) => { out += d; }); ch.stderr.on('data', (d) => { err += d; });
    ch.on('error', (x) => fin({ code: null, absent: x.code === 'ENOENT', err: String(x.message) }));
    ch.on('close', (code) => fin({ code: tue ? null : code }));
    if (entree != null) { ch.stdin.on('error', () => {}); ch.stdin.write(entree); }
  });
}

// ── Jauges (port de jauges.py) : Codex via `app-server` (JSON-RPC), Gemini via `/usage`. Rien de secret n'est lu ni gardé.
async function jaugeGpt() {
  const msgs = ['{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"clientInfo":{"name":"deleguer","version":"0.1"}}}', '{"jsonrpc":"2.0","method":"initialized"}', '{"jsonrpc":"2.0","id":2,"method":"account/rateLimits/read"}'].join('\n') + '\n';
  const r = await executer([BIN.gpt(), 'app-server'], { cwd: os.tmpdir(), delai: 20, entree: msgs, env: envAbonnement() });
  const l = r.out.split('\n').find((x) => x.includes('"id":2'));
  if (!l) return null;
  const rl = JSON.parse(l).result?.rateLimits;
  return rl ? { cinq_h_utilise: rl.primary?.usedPercent ?? null, semaine_utilisee: rl.secondary?.usedPercent ?? null } : null;
}
async function jaugeGemini() {
  const r = await executer([BIN.gemini(), '-p', '/usage', '--output-format', 'json'], { cwd: os.tmpdir(), delai: 60, env: envAbonnement() });
  const txt = jsonDepuis(r.out).response || ''; const d = {};
  for (const l of txt.split('\n')) { const c = l.split('\t'); if (c.length >= 3) d[`${c[0]} ${c[1]}`.replace(' Limit Remaining', '').replace(/ /g, '_').toLowerCase()] = parseInt(c[2], 10); }
  if (d.gemini_models_five_hour == null && d.gemini_models_weekly == null) return null;
  return { cinq_h_reste: d.gemini_models_five_hour ?? null, semaine_reste: d.gemini_models_weekly ?? null };
}
export async function jauge(p) {
  if (process.env.DELEGUER_SANS_JAUGES === '1' || p === 'claude') return null;
  try { return p === 'gpt' ? await jaugeGpt() : await jaugeGemini(); } catch { return null; }
}
// Le refus, ou null. Une jauge illisible ne bloque pas (elle est signalée par quota_avant: null).
export function refusQuota(p, q) {
  if (!q) return null;
  if (p === 'gemini' && q.cinq_h_reste != null && q.cinq_h_reste < SEUILS.gemini_5h_reste_min) return `Gemini : ${q.cinq_h_reste} % restant sur la limite 5 h (seuil ${SEUILS.gemini_5h_reste_min} %). Attendre la remise à zéro ou confier à GPT ou Claude.`;
  if (p === 'gemini' && q.semaine_reste != null && q.semaine_reste < SEUILS.gemini_semaine_reste_min) return `Gemini : ${q.semaine_reste} % restant sur la limite de la semaine (seuil ${SEUILS.gemini_semaine_reste_min} %). Confier à GPT ou Claude.`;
  if (p === 'gpt' && q.semaine_utilisee != null && q.semaine_utilisee > SEUILS.gpt_semaine_max) return `GPT (Codex) : ${q.semaine_utilisee} % de la semaine consommés (seuil ${SEUILS.gpt_semaine_max} %). Confier à Gemini ou Claude.`;
  if (p === 'gpt' && q.cinq_h_utilise != null && q.cinq_h_utilise > SEUILS.gpt_5h_max) return `GPT (Codex) : ${q.cinq_h_utilise} % de la limite 5 h consommés (seuil ${SEUILS.gpt_5h_max} %). Attendre ou confier à Gemini ou Claude.`;
  return null;
}

// Abonnement : on retire les clés d'API pour qu'aucun appel ne parte en facturation à l'usage.
function envAbonnement() {
  const e = { ...process.env, CLAUDE_CODE_DISABLE_CLAUDE_MDS: '1' };
  for (const k of ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'CODEX_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY']) delete e[k];
  return e;
}

const IMAGES = /\.(png|jpe?g|webp|gif)$/i;
const liste = (d) => { try { return fs.readdirSync(d); } catch { return []; } };
// Gemini range ses images générées sous brain/<session>/…/media/ : on prend celles apparues depuis le début de l'appel.
export function imagesGemini(depuis, brain = process.env.DELEGUER_BRAIN || path.join(os.homedir(), '.gemini/antigravity-cli/brain')) {
  const trouvees = [];
  const marche = (d, prof) => { for (const n of liste(d)) { const f = path.join(d, n); let s; try { s = fs.statSync(f); } catch { continue; }
    if (s.isDirectory() && prof < 7) marche(f, prof + 1); else if (s.isFile() && IMAGES.test(n) && s.mtimeMs >= depuis - 1000) trouvees.push({ f, t: s.mtimeMs }); } };
  marche(brain, 0);
  return trouvees.sort((a, b) => a.t - b.t).map((x) => x.f);
}

export function lireArgs(argv) {
  const o = {}; const BOOL = ['a-sec'];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]; if (!a.startsWith('--')) throw new Error(`argument inattendu : ${a}`);
    const k = a.slice(2); if (BOOL.includes(k)) { o[k] = true; continue; }
    if (i + 1 >= argv.length) throw new Error(`${a} attend une valeur`); o[k] = argv[++i];
  }
  return o;
}
export function valider(o) {
  const mal = [];
  if (!FOURNISSEURS.includes(o.a)) mal.push('--a doit être gpt, gemini ou claude');
  if (!o.modele) mal.push('--modele manque');
  if (o.effort === 'max') mal.push("l'effort max est refusé");
  else if (!EFFORTS.includes(o.effort)) mal.push('--effort doit être low, medium, high ou xhigh');
  if (/astra/i.test(o.modele || '')) mal.push('le modèle Astra est refusé');
  if (!MODES.includes(o.mode)) mal.push(`--mode doit être ${MODES.join(', ')}`);
  if (!o.dossier) mal.push('--dossier manque');
  if (!o.brief && !o.prompt) mal.push('--brief ou --prompt manque');
  if (o.brief && o.prompt) mal.push('--brief et --prompt ensemble : en choisir un');
  if (o.type && !TYPES.includes(o.type)) mal.push(`--type doit être ${TYPES.join(', ')}`);
  if (o.a === 'claude' && o.mode === 'image') mal.push('Claude ne génère pas d\'image : confier à gpt ou gemini');
  if (o.a === 'claude' && o.reference) mal.push('--reference : seulement gpt et gemini');
  if (o.delai != null && !(Number(o.delai) > 0)) mal.push('--delai doit être un nombre de secondes positif');
  if (o.a === 'claude' && /^(haiku|sonnet|opus)$/i.test(o.modele || '')) mal.push("--modele : l'id complet (claude-haiku-5-5), pas l'alias, qui peut viser un ancien modèle");
  return mal;
}
const TYPE_PAR_MODE = { image: 'image', web: 'veille', fichiers: 'code', lecture: 'relecture', texte: 'redaction' };
const estimer = (o, prompt) => ({ jetons_entree_environ: Math.ceil(prompt.length / 4), duree_s_environ: { texte: 20, lecture: 40, fichiers: 90, web: 120, image: 120 }[o.mode], quota: o.a === 'claude' ? 'abonnement Claude (poids de la fille)' : o.a === 'gpt' ? 'limite 5 h et semaine Codex' : 'limite 5 h et semaine Gemini' });

// Une ligne du journal, au format de outils/bancs/intermodele/README.md. Rien de privé : tâche assainie, source réduite à un nom.
export function ligneJournal({ o, r, duree, jetons, quotaAvant, quotaApres, fichiers, ok }) {
  const dQ = (k, signe = 1) => quotaAvant && quotaApres && quotaAvant[k] != null && quotaApres[k] != null ? signe * (quotaApres[k] - quotaAvant[k]) : null;
  const pts = o.a === 'gpt' ? dQ('cinq_h_utilise') : o.a === 'gemini' ? dQ('cinq_h_reste', -1) : null;
  const total = jetons.entree + jetons.sortie + jetons.raisonnement;
  const attendus = o.mode === 'image' || o.mode === 'fichiers';
  const conf = ok && (!attendus || fichiers.length > 0);
  return {
    date: new Date().toISOString(), compte: compteLocal(),
    tache: assainir(o.tache || `deleguer-${o.type || TYPE_PAR_MODE[o.mode]}`, 120), type: o.type || TYPE_PAR_MODE[o.mode],
    fournisseur: o.a, modele: assainir(o.modele, 60), voie: 'abonnement', cout_eur: 0,
    quota_consomme: `${total} jetons${o.a === 'claude' ? '' : o.a === 'gpt' ? ' Codex' : ' Gemini'}${pts != null ? ` ; limite 5 h ${pts >= 0 ? '+' : ''}${pts} pt` : ''}`,
    duree_s: duree,
    conformite: { score: conf ? 1 : 0, detail: !ok ? 'pas de réponse exploitable' : attendus ? (fichiers.length ? `${fichiers.length} fichier(s) livré(s)` : 'aucun fichier livré') : 'réponse non vide' },
    qualite: { note: null, juge: null, commentaire: 'non jugée (livré par deleguer.mjs ; à juger par l\'orchestratrice)' },
    source: fichiers[0] ? assainir(path.basename(fichiers[0]), 60) : 'deleguer.mjs',
  };
}
export function journaliser(ligne) {
  const dir = process.env.ORCH_INTERMODELE || path.join(os.homedir(), '.cache/orchestration/intermodele');
  fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(path.join(dir, `${ligne.fournisseur}.jsonl`), JSON.stringify(ligne) + '\n');
}

export async function deleguer(o) {
  const mal = valider(o);
  if (mal.length) return { ok: false, erreur: 'arguments', message: mal.join(' ; '), code: 2 };
  const dossier = path.resolve(o.dossier); const delai = Number(o.delai || 600);
  let corps = o.prompt;
  if (o.brief) { try { corps = fs.readFileSync(o.brief, 'utf8'); } catch { return { ok: false, erreur: 'arguments', message: `brief illisible : ${path.basename(o.brief)}`, code: 2 }; } }
  let ref = null;
  if (o.reference) { ref = path.resolve(o.reference); if (!fs.existsSync(ref)) return { ok: false, erreur: 'arguments', message: `référence introuvable : ${path.basename(o.reference)}`, code: 2 }; }
  const pre = PREAMBULE[o.a === 'gemini' && o.mode === 'web' ? 'web_agy' : o.mode];
  let prompt = pre + corps;
  const images = [];
  if (ref && o.a === 'gpt') images.push(ref);
  const argvSec = () => commande(o.a, o.modele, o.effort, prompt, o.mode, images);
  if (o['a-sec']) {
    if (ref && o.a === 'gemini') prompt = `${pre}Une image de reference est fournie dans le dossier courant (reference${path.extname(ref)}) : tiens-en le style. ${corps}`;
    const argv = argvSec().map((x) => x === prompt ? `<prompt : ${prompt.length} caractères>` : x);
    return { ok: true, a_sec: true, commande: argv, dossier, delai_s: delai, estimation: estimer(o, prompt), seuils: SEUILS, journal: path.join(process.env.ORCH_INTERMODELE || '~/.cache/orchestration/intermodele', `${o.a}.jsonl`), code: 0 };
  }
  fs.mkdirSync(dossier, { recursive: true });
  const quotaAvant = await jauge(o.a);
  const refus = refusQuota(o.a, quotaAvant);
  if (refus) return { ok: false, texte: '', fichiers: [], erreur: 'quota', refus: true, message: refus, quota_avant: quotaAvant, quota_apres: null, code: 3 };
  if (ref && o.a === 'gemini') { // Gemini ne prend pas d'option image : la référence est copiée dans le dossier et nommée dans le prompt
    const nom = `reference${path.extname(ref)}`; fs.copyFileSync(ref, path.join(dossier, nom));
    prompt = `${pre}Une image de reference est fournie dans le dossier courant (${nom}) : tiens-en le style. ${corps}`;
  }
  const avant = new Set(liste(dossier)); const t0 = Date.now();
  const r = await executer(commande(o.a, o.modele, o.effort, prompt, o.mode, images), { cwd: dossier, delai, env: envAbonnement() });
  const duree = Math.round((Date.now() - t0) / 100) / 10;
  const brut = { texte: '', entree: 0, cache: 0, sortie: 0, raisonnement: 0 };
  const sortie = (extra) => ({ texte: '', fichiers: [], jetons: { entree: 0, cache: 0, sortie: 0, raisonnement: 0 }, duree_s: duree, quota_avant: quotaAvant, quota_apres: null, ...extra });
  if (r.absent) return { ...sortie({ ok: false, erreur: 'binaire', message: `binaire introuvable : ${path.basename(BIN[o.a]())} (variable DELEGUER_${o.a === 'gpt' ? 'CODEX' : o.a === 'gemini' ? 'AGY' : 'CLAUDE'})` }), code: 1 };
  if (r.delaiDepasse) return { ...sortie({ ok: false, erreur: 'delai', message: `délai de ${delai} s dépassé ; processus arrêté` }), code: 1 };
  let L; try { L = lire(o.a, r.out); } catch { L = brut; }
  // Classement : une limite d'abonnement est « quota », jamais un échec de la tâche.
  if ((L.erreurModele || !L.texte) && LIMITE.test(`${r.out}\n${r.err}\n${L.texte}`)) {
    return { ...sortie({ ok: false, jetons: { entree: L.entree, cache: L.cache, sortie: L.sortie, raisonnement: L.raisonnement }, erreur: 'quota', message: 'limite atteinte chez le fournisseur ; réessayer après la remise à zéro ou changer de fournisseur' }), code: 3 };
  }
  let fichiers = liste(dossier).filter((n) => !avant.has(n)).sort();
  if (o.a === 'gemini' && o.mode === 'image') {
    for (const f of imagesGemini(t0)) { let n = path.basename(f); if (fichiers.includes(n) || avant.has(n)) n = `gemini-${Date.now()}-${n}`; fs.copyFileSync(f, path.join(dossier, n)); fichiers.push(n); }
  }
  const ok = !L.erreurModele && (!!L.texte || fichiers.length > 0 && (o.mode === 'fichiers' || o.mode === 'image'));
  const jetons = { entree: L.entree, cache: L.cache, sortie: L.sortie, raisonnement: L.raisonnement };
  const quotaApres = await jauge(o.a);
  const res = sortie({ ok, texte: L.texte, fichiers, jetons, quota_apres: quotaApres, erreur: ok ? null : (r.code ? `sortie ${r.code} : ${assainir(r.err || L.texte, 200)}` : 'reponse vide'), code: ok ? 0 : 1 });
  try { journaliser(ligneJournal({ o, r: res, duree, jetons, quotaAvant, quotaApres, fichiers, ok })); } catch { res.journal = 'non ecrit'; }
  return res;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])) {
  let res;
  try { res = await deleguer(lireArgs(process.argv.slice(2))); } catch (x) { res = { ok: false, erreur: 'arguments', message: String(x.message), code: 2 }; }
  const { code = res.ok ? 0 : 1, ...json } = res;
  process.stdout.write(JSON.stringify(json) + '\n');
  process.exit(code);
}
