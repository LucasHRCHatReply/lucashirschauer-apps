#!/usr/bin/env node
// La fabrique de skills de métier : lit les retours de tous les comptes (perfs/<compte>/retours.jsonl) et dit
//   1. les candidates : une même tâche, aux prompts proches, réussie au moins 3 fois en 30 jours sans skill de métier ;
//   2. les skills à affiner : une skill de skills/metiers/ avec au moins 2 échecs ou corrections sur ses 10 derniers usages ;
//   3. les skills à descendre d'un cran : 3 réussites de suite au même modèle, on essaie le modèle du dessous ;
//   4. les cas peu exemplifiés : un couple tâche · modèle vu moins de 3 fois, que /retour doit nourrir en priorité.
// Usage : node outils/candidats-skills.mjs [--json] [--jours 30]   (ORCH_PERFS, ORCH_METIERS pour les essais)
// Lancé par la passe d'affinage (outils/affinage.sh) et par le hook verdict pour juger si un retour est intéressant.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const RACINE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const PERFS = process.env.ORCH_PERFS || path.join(RACINE, 'perfs');
export const METIERS = process.env.ORCH_METIERS || path.join(RACINE, 'skills', 'metiers');
const REUSSI = new Set(['reussi', 'reussi-apres-correction']);
const CRANS = ['haiku', 'sonnet', 'opus', 'fable'];
// La cause d'un raté (skills/retour, agents/verificateur.md) et la partie de la skill de métier que l'affinage réécrit pour elle.
export const CAUSES = ['contexte', 'tache', 'contrainte', 'format', 'section', 'coordination', 'capacite', 'outil'];
export const SECTION = { contexte: 'le contexte à fournir (fichiers, faits)', tache: 'le verbe et le but du prompt', contrainte: 'les contraintes et le périmètre',
  format: 'le format de sortie', section: 'la partie du prompt qui rate, seule', coordination: 'la fondation ou la décision partagée',
  capacite: 'le champ modele (monter d\'un cran)', outil: 'le champ fonctionnalite (outil ou accès)' };

const lire = f => { try { return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).flatMap(l => { try { return [JSON.parse(l)]; } catch { return []; } }); } catch { return []; } };
export const retours = (dossier = PERFS) => { try { return fs.readdirSync(dossier, { withFileTypes: true }).filter(d => d.isDirectory())
  .flatMap(d => lire(path.join(dossier, d.name, 'retours.jsonl')).map(r => ({ ...r, compte: r.compte || d.name }))); } catch { return []; } };
export const skillsMetiers = (dossier = METIERS) => { try { return fs.readdirSync(dossier).filter(n => fs.existsSync(path.join(dossier, n, 'SKILL.md'))); } catch { return []; } };

// Les mots qui portent le sens d'un prompt généralisé (sans les mots outils, sans accents).
const VIDES = new Set('les des une un le la de du et en au aux pour par sur avec dans qui que quoi est sont ce cette ces son sa ses on ou a format chaque tout toute tous'.split(' '));
export const mots = s => new Set(String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/[^a-z0-9]+/).filter(m => m.length > 2 && !VIDES.has(m)));
export const proximite = (a, b) => { const A = mots(a), B = mots(b); if (!A.size || !B.size) return 0; let c = 0; for (const m of A) if (B.has(m)) c++; return c / (A.size + B.size - c); };

// Regroupe les retours d'une même tâche dont les prompts se ressemblent (Jaccard ≥ seuil avec le premier du groupe).
export function grouper(liste, seuil = 0.3) {
  const groupes = [];
  for (const r of liste) {
    const g = groupes.find(g => g.tache === r.tache && proximite(g.modele_prompt, r.prompt_generalise) >= seuil);
    if (g) g.retours.push(r); else groupes.push({ tache: r.tache, modele_prompt: r.prompt_generalise, retours: [r] });
  }
  return groupes;
}

export function analyser({ liste = retours(), metiers = skillsMetiers(), jours = 30, maintenant = Date.now() } = {}) {
  const depuis = maintenant - jours * 864e5;
  const recents = liste.filter(r => Date.parse(r.date) >= depuis && r.tache && r.tache !== 'autre');
  const sansSkill = recents.filter(r => !r.skill || !metiers.includes(r.skill));
  const candidates = grouper(sansSkill).map(g => {
    const ok = g.retours.filter(r => REUSSI.has(r.verdict));
    const meilleur = ok.find(r => r.verdict === 'reussi') || ok[0];
    const modeles = {}; for (const r of ok) modeles[`${r.modele} · ${r.effort}`] = (modeles[`${r.modele} · ${r.effort}`] || 0) + 1;
    return { tache: g.tache, reussites: ok.length, usages: g.retours.length, comptes: [...new Set(g.retours.map(r => r.compte))],
      prompt: meilleur?.prompt_generalise || g.modele_prompt, modele: Object.entries(modeles).sort((a, b) => b[1] - a[1])[0]?.[0] || 'n/a',
      critere: meilleur?.critere || 'n/a', lecons: [...new Set(g.retours.map(r => r.lecon).filter(Boolean))].slice(0, 3) };
  }).filter(c => c.reussites >= 3).sort((a, b) => b.reussites - a.reussites);

  const parSkill = {};
  for (const r of liste.filter(r => r.skill && metiers.includes(r.skill)).sort((a, b) => String(a.date).localeCompare(String(b.date)))) (parSkill[r.skill] ||= []).push(r);
  const aAffiner = [], aDescendre = [];
  for (const [skill, us] of Object.entries(parSkill)) {
    const derniers = us.slice(-10), rates = derniers.filter(r => r.verdict !== 'reussi');
    if (rates.length >= 2) {
      const parCause = {}; for (const r of rates) { const c = CAUSES.includes(r.cause) ? r.cause : 'non-dite'; parCause[c] = (parCause[c] || 0) + 1; }
      const dominante = Object.entries(parCause).filter(([c]) => c !== 'non-dite').sort((a, b) => b[1] - a[1])[0]?.[0] || null;
      aAffiner.push({ skill, usages: derniers.length, rates: rates.length, parCause, dominante, section: dominante ? SECTION[dominante] : null,
        causes: rates.map(r => r.ce_qui_a_rate).filter(Boolean).slice(-3) });
    }
    const trois = us.slice(-3);
    if (trois.length === 3 && trois.every(r => r.verdict === 'reussi' && r.modele === trois[0].modele && r.montee === 'aucune')) {
      const i = CRANS.indexOf(trois[0].modele); if (i > 0) aDescendre.push({ skill, modele: trois[0].modele, essayer: CRANS[i - 1] });
    }
  }

  const vus = {}; for (const r of recents) { const k = `${r.tache} · ${r.modele}`; vus[k] = (vus[k] || 0) + 1; }
  const peuExemplifies = Object.entries(vus).filter(([, n]) => n < 3).map(([cas, n]) => ({ cas, n })).sort((a, b) => a.n - b.n);
  return { date: new Date(maintenant).toISOString().slice(0, 10), jours, retours: recents.length, metiers, candidates, aAffiner, aDescendre, peuExemplifies, vus };
}

// Vrai si ce couple tâche · modèle a moins de 3 exemples sur la période : le hook verdict demande alors un retour.
export const peuExemplifie = (tache, modele, a = analyser()) => (a.vus[`${tache} · ${modele}`] || 0) < 3;

export function texte(a) {
  const l = [`# Fabrique de skills — ${a.date}`, '', `${a.retours} retours sur ${a.jours} jours · ${a.metiers.length} skill(s) de métier : ${a.metiers.join(', ') || 'aucune'}.`,
    'Source : `perfs/*/retours.jsonl`, `node outils/candidats-skills.mjs`.', '', '## Candidates (≥ 3 réussites, sans skill)', ''];
  if (!a.candidates.length) l.push('Aucune : pas encore 3 réussites d\'une même tâche aux prompts proches.');
  for (const c of a.candidates) l.push(`- **${c.tache}** — ${c.reussites}/${c.usages} réussites, ${c.comptes.length} compte(s), ${c.modele} ; contrôle : ${c.critere}`, `  - prompt : « ${c.prompt} »`, ...c.lecons.map(x => `  - leçon : ${x}`));
  l.push('', '## À affiner (≥ 2 ratés sur les 10 derniers usages)', '', ...(a.aAffiner.length ? a.aAffiner.map(s => `- **${s.skill}** — ${s.rates}/${s.usages} ratés ; causes : ${Object.entries(s.parCause).map(([c, n]) => `${c} ×${n}`).join(', ')}${s.dominante ? ` → réécrire ${s.section}` : ''}${s.causes.length ? ` ; ${s.causes.join(' · ')}` : ''}`) : ['Aucune.']));
  l.push('', '## À descendre d\'un cran (3 réussites de suite)', '', ...(a.aDescendre.length ? a.aDescendre.map(s => `- **${s.skill}** — ${s.modele} → essayer ${s.essayer}`) : ['Aucune.']));
  l.push('', '## Peu exemplifiés (< 3 retours) : /retour en priorité', '', ...(a.peuExemplifies.length ? a.peuExemplifies.map(p => `- ${p.cas} : ${p.n}`) : ['Aucun retour sur la période : tout cas est peu exemplifié.']));
  return l.join('\n') + '\n';
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const i = process.argv.indexOf('--jours'); const a = analyser({ jours: i > 0 ? Number(process.argv[i + 1]) : 30 });
  process.stdout.write(process.argv.includes('--json') ? JSON.stringify(a, null, 2) + '\n' : texte(a));
}
