#!/usr/bin/env node
// Porte du brief, sans modèle : un brief ne part pas s'il lui manque un des composants que la fille ne peut pas deviner.
// Le skill contrôle le rendu d'une fille (§ 3 b) ; ce script contrôle son entrée (§ 4), avant le départ.
//
//   node outils/brief.mjs <brief.md>               rôle, but, critère de fin en commande, zone, rapport à 5 champs
//   node outils/brief.mjs --parallele <brief.md>   en plus : ce que traitent les autres filles
//   node outils/brief.mjs --json <brief.md>
//
// Conseils (⚠, sans effet sur le code) : la ligne « n/a — non couvert » qui donne à la fille le droit de ne pas savoir (3.11.0) ;
// le mot vague sans seuil sur une ligne but ou critère (test des deux lecteurs, 4.0.0).
// Code 0 : tout est là. Code 1 : il manque au moins un composant (la liste dit lequel). Code 2 : arguments ou fichier.
// Contrôle volontairement lâche (mots-clés français ou anglais) : il attrape l'oubli, il ne juge pas la qualité.
import fs from 'node:fs';

export const COMPOSANTS = [
  { cle: 'role', nom: 'rôle', aide: 'une phrase « Tu es … » ou « Rôle : … » en tête',
    test: (t) => /^\s*(?:[-*>#]\s*)*(?:\*\*)?(tu es|vous êtes|you are|r[ôo]le\s*:)/im.test(t) },
  { cle: 'but', nom: 'but', aide: '« But : » en une phrase',
    test: (t) => /\b(but|objectif|goal|objective)\s*(?:\*\*)?\s*:/i.test(t) },
  { cle: 'critere', nom: 'critère de fin en commande', aide: 'une ligne « Critère … » qui porte une commande entre accents graves',
    test: (t) => t.split('\n').some((l) => /crit[eè]re|done when|acceptance/i.test(l) && /`[^`]+`/.test(l)) },
  { cle: 'zone', nom: 'zone', aide: '« Zone : » (dépôt, dossier, fichiers) ou ce qu\'il ne faut pas toucher',
    test: (t) => /\bzone\s*(?:\*\*)?\s*:|ne (?:pas )?touche|do not (?:touch|modify)|scope\s*:/i.test(t) },
  { cle: 'rapport', nom: 'rapport à 5 champs', aide: 'le rapport attendu : fait, preuve, non fait ou non vérifié, décisions, ce qui attend l\'humain',
    test: (t) => /rapport|report/i.test(t) && /preuve|proof|evidence/i.test(t) && /non (?:fait|v[ée]rifi[ée])|not (?:done|verified)/i.test(t) },
];
export const PARALLELE = { cle: 'autres', nom: 'ce que traitent les autres filles', aide: 'une ligne par fille parallèle, pour ne pas refaire son travail',
  // La ligne doit dire ce qu'elles traitent (un fichier, un chemin ou un élément entre accents graves), pas seulement qu'elles existent.
  test: (t) => t.split('\n').some((l) => /autres? (?:filles?|agents?|sessions?)|other (?:agents?|subagents?)|en parall[eè]le\s*:/i.test(l) && /`[^`]+`|\w\/|\.\w{2,4}\b/.test(l)) };

export const CONSEILS = [
  { cle: 'non-couvert', nom: 'droit de ne pas savoir', aide: '« ce que les sources ne couvrent pas s\'écrit `n/a — non couvert`, jamais deviné »',
    test: (t) => /non couvert|ne sais pas|not covered|i don'?t know/i.test(t) },
  { cle: 'seuil', nom: 'mot vague sans seuil', aide: 'sur les lignes but et critère, chaque mot comme « rapide », « propre », « suffisant » porte un chiffre (« sous 800 ms », « 0 avertissement ») : deux lecteurs doivent conclure pareil',
    test: (t) => vagues(t).length === 0 },
];

// Test des deux lecteurs (P15) : un mot vague sur une ligne but ou critère, sans chiffre hors des accents graves.
export const MOTS_VAGUES = /\b(rapide(?:ment)?|propre(?:ment)?|bien|suffisa(?:nt|nte|nts|ntes|mment)|correcte?(?:ment)?|assez|quelques|fiables?|robustes?|am[ée]lior\w*|nettement|optimis\w*|performante?s?|clean|fast|good|enough|some|robust|improv\w*)\b/giu;
export function vagues(t) {
  return t.split('\n').filter((l) => /\b(but|objectif|goal|crit[eè]re|done when|acceptance)\b/i.test(l)).flatMap((l) => {
    const hors = l.replace(/`[^`]*`/g, ' ');
    return /\d/.test(hors) ? [] : [...hors.matchAll(MOTS_VAGUES)].map((m) => m[0].toLowerCase());
  });
}

export function controler(texte, { parallele = false } = {}) {
  const liste = parallele ? [...COMPOSANTS, PARALLELE] : COMPOSANTS;
  const resultats = liste.map((c) => ({ cle: c.cle, nom: c.nom, aide: c.aide, ok: c.test(texte) }));
  const conseils = CONSEILS.map((c) => ({ cle: c.cle, nom: c.nom, aide: c.aide, ok: c.test(texte), ...(c.cle === 'seuil' ? { mots: vagues(texte) } : {}) }));
  return { ok: resultats.every((r) => r.ok), resultats, conseils };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const parallele = args.includes('--parallele'); const json = args.includes('--json');
  const fichier = args.find((a) => !a.startsWith('--'));
  if (!fichier) { console.error('usage : node outils/brief.mjs [--parallele] [--json] <brief.md>'); process.exit(2); }
  let texte; try { texte = fs.readFileSync(fichier, 'utf8'); } catch { console.error(`brief illisible : ${fichier}`); process.exit(2); }
  const r = controler(texte, { parallele });
  if (json) console.log(JSON.stringify(r));
  else {
    for (const x of r.resultats) console.log(`${x.ok ? '✓' : '✗'} ${x.nom}${x.ok ? '' : ` — manque : ${x.aide}`}`);
    for (const x of r.conseils) if (!x.ok) console.log(`⚠ ${x.nom}${x.mots?.length ? ` (${[...new Set(x.mots)].join(', ')})` : ''} — conseillé : ${x.aide}`);
    console.log(r.ok ? 'brief complet : il peut partir' : 'brief incomplet : le compléter avant le départ');
  }
  process.exit(r.ok ? 0 : 1);
}
