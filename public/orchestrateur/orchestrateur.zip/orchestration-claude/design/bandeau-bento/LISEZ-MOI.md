# Design system du bandeau d'orchestration — bento selon la largeur

Source de vérité du rendu de `mod/bandeau-orchestration/hooks/register.tsx`. Pour changer le bandeau, on change d'abord la maquette ici (ou sur le canevas), puis on reporte dans le code.

- **Canevas Claude Design** : https://claude.ai/artifact/QP6h8D9VHmcNMjZVQoiZ4T (trois planches, notes « règles » et « stagiaire »). Les fichiers de ce dossier en sont la copie du 23/11/2026 : `canvas.json`, `Main.dc.html` (large), `Moyen.dc.html`, `Etroit.dc.html`. `support.js` appartient au type d'artifact et n'est pas copié ; on rouvre les planches sur le canevas, pas en local.
- **Design system de base** : Reply Design System (https://claude.ai/artifact/TXpWj5K3TPvWWnWiugU4y2, version 1795252769-8d3b).

## Trois paliers, choisis par `bodyColumns` (largeur du terminal en colonnes)

| Palier | Largeur | Disposition |
|---|---|---|
| Large | 140 colonnes et plus | Étape (plan entier) · colonne « En attente » + « Qui travaille » · colonne Contexte + Coût |
| Moyen | 80 à 139 | « En attente » sur toute la largeur en tête, puis Étape · chiffres, puis « Qui travaille » |
| Étroit | moins de 80 | une colonne : En attente, Étape, une ligne de puces (Contexte, Coût), Qui travaille |

Replié (par défaut), le bandeau tient sur une ligne, plus une ligne « ↳ activité » ; c'est identique dans les trois paliers.

## Jetons (couleurs Reply, une couleur ne sert qu'au signal)

| Jeton | Valeur | Sert à |
|---|---|---|
| ciel | `#4bdcfe` | tuile Étape, étape en cours |
| bleu | `#009eff` | jauge du contexte |
| succes | `#23cc99` | étape faite, quelqu'un travaille |
| erreur | `#de0c48` | « En attente », contexte au-delà de 75 % de 180 k |
| indigo | `#8f7dfa` | modèle · effort (dans la maquette, `#3d27c9` sur fond clair) |
| bord | `#5c6d73` | bordure des tuiles neutres (rondes) |
| discret | `#41555b` | segments à venir, fond des jauges |
| fond Étape (maquette) | `#053238` | la tuile principale ; le terminal garde son fond, la bordure ciel le remplace |
| fond Attente (maquette) | `#fce3ea` | même chose, bordure erreur dans le terminal |

Typographie de la maquette : libellés 11 px en majuscules `#5c6d73`, valeurs en Arial Black, chiffres en `tabular-nums`. Dans le terminal : titre de tuile en gras, valeurs en gras.

## Règles (veille Gemini du 23/11, 22 composants comparés)

1. Ce qui attend l'utilisateur passe en tête dès que la fenêtre rétrécit, et n'apparaît pas s'il n'y a rien.
2. L'étape n/N reste toujours visible.
3. Agents, coût, contexte se replient en puces avant de disparaître.
4. Le bandeau ne dépasse pas 15 à 20 % de la hauteur ; il est replié par défaut sur une ligne.
5. Chiffres en largeur fixe ; un état affiché au moins 400 ms, pour ne pas clignoter.
6. Aucun pourcentage inventé : une étape vérifiée, ou un indicateur d'activité.

Le stagiaire local s'affiche ◐ dans « Qui travaille », avec son modèle et son taux de réussite (voir `outils/stagiaire.mjs`).
